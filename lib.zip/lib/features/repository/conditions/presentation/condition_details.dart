import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zim_herbs_repo/features/repository/conditions/data/repository/condition_repository.dart';
import 'package:zim_herbs_repo/features/repository/conditions/data/repository/model.dart';
import 'package:zim_herbs_repo/features/repository/conditions/bloc/condition_detail_cubit.dart';
import 'package:zim_herbs_repo/core/theme/spacing.dart';
import 'package:zim_herbs_repo/core/utils/enums.dart';
import 'package:zim_herbs_repo/core/utils/responsive.dart';
import 'package:zim_herbs_repo/core/utils/responsive_sizes.dart';

class ConditionDetailsPage extends StatefulWidget {
  final String conditionId;

  const ConditionDetailsPage({super.key, required this.conditionId});

  @override
  State<ConditionDetailsPage> createState() => _ConditionDetailsPageState();
}

class _ConditionDetailsPageState extends State<ConditionDetailsPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final rs = ResponsiveSize(context);

    return BlocProvider(
      create:
          (context) =>
              ConditionDetailCubit(ConditionRepository())
                ..loadCondition(widget.conditionId),
      child: BlocBuilder<ConditionDetailCubit, ConditionDetailState>(
        builder: (context, state) {
          if (state is ConditionDetailLoading ||
              state is ConditionDetailInitial) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }

          if (state is ConditionDetailError) {
            return Scaffold(
              appBar: AppBar(
                backgroundColor: Theme.of(context).colorScheme.primary,
                leading: IconButton(
                  icon: const Icon(Icons.arrow_back, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
              body: Center(child: Text(state.message)),
            );
          }

          if (state is ConditionDetailLoaded) {
            final condition = state.condition;
            final systemColor = getBodySystemColor(condition.bodySystem);

            return Scaffold(
              backgroundColor: Theme.of(context).scaffoldBackgroundColor,
              body: CustomScrollView(
                slivers: [
                  SliverAppBar(
                    centerTitle: true,
                    expandedHeight: Responsive.isMobile(context) ? 200 : 250,
                    pinned: true,
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    leading: IconButton(
                      icon: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: const BoxDecoration(
                          color: Colors.black26,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.arrow_back,
                          color: Theme.of(context).colorScheme.secondary,
                          size: rs.appBarIcon,
                        ),
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                    flexibleSpace: FlexibleSpaceBar(
                      centerTitle: true,
                      title: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            condition.name,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: rs.appBarTitleFont,
                              color: Theme.of(context).colorScheme.secondary,
                            ),
                          ),
                        ),
                      ),
                      background: Container(
                        color: systemColor.withValues(alpha: 0.1),
                        child: Center(
                          child: Opacity(
                            opacity: 0.2,
                            child: SvgPicture.asset(
                              getBodySystemSvg(condition.bodySystem),
                              width: 120,
                              height: 120,
                              colorFilter: const ColorFilter.mode(
                                Colors.white,
                                BlendMode.srcIn,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: FadeTransition(
                      opacity: _fadeAnimation,
                      child: SlideTransition(
                        position: _slideAnimation,
                        child: Center(
                          child: ConstrainedBox(
                            constraints: BoxConstraints(
                              maxWidth:
                                  Responsive.isMobile(context)
                                      ? double.infinity
                                      : 800,
                            ),
                            child: Padding(
                              padding: EdgeInsets.all(defaultPadding),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _buildHeaderChips(condition, rs),
                                  const SizedBox(height: 24),
                                  if (condition.description != null &&
                                      condition.description!.isNotEmpty)
                                    _buildSectionCard(
                                      icon: Icons.description_outlined,
                                      title: "Description",
                                      content: Text(
                                        condition.description!,
                                        style: TextStyle(
                                          fontSize: rs.bodyFont,
                                          height: 1.5,
                                          color: Colors.black,
                                        ),
                                      ),
                                      rs: rs,
                                      accentColor: systemColor,
                                    ),
                                  if (condition.symptoms.isNotEmpty) ...[
                                    const SizedBox(height: 24),
                                    _buildSectionCard(
                                      icon: Icons.list_alt,
                                      title: "Common Symptoms",
                                      content: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children:
                                            condition.symptoms
                                                .map(
                                                  (s) =>
                                                      _buildBulletPoint(s, rs),
                                                )
                                                .toList(),
                                      ),
                                      rs: rs,
                                      accentColor: systemColor,
                                    ),
                                  ],
                                  if (condition.precautions.isNotEmpty) ...[
                                    const SizedBox(height: 24),
                                    _buildSectionCard(
                                      icon: Icons.warning_amber_rounded,
                                      title: "Precautions",
                                      content: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children:
                                            condition.precautions
                                                .map(
                                                  (p) =>
                                                      _buildBulletPoint(p, rs),
                                                )
                                                .toList(),
                                      ),
                                      rs: rs,
                                      accentColor: Colors.orange,
                                    ),
                                  ],
                                  const SizedBox(height: 32),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }

          return const SizedBox.shrink();
        },
      ),
    );
  }

  Widget _buildHeaderChips(ConditionModel condition, ResponsiveSize rs) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        Chip(
          avatar: Icon(
            Icons.info_outline,
            size: 16,
            color: Theme.of(context).colorScheme.onPrimary,
          ),
          label: Text(
            bodySystemLabel(condition.bodySystem),
            style: TextStyle(
              color: Theme.of(context).colorScheme.onPrimary,
              fontWeight: FontWeight.bold,
              fontSize: rs.labelFont,
            ),
          ),
          backgroundColor: Theme.of(context).colorScheme.primary,
          side: BorderSide.none,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        ),
      ],
    );
  }

  Widget _buildBulletPoint(String text, ResponsiveSize rs) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                color: Colors.black54,
                shape: BoxShape.circle,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: rs.bodyFont, color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionCard({
    required IconData icon,
    required String title,
    required Widget content,
    required ResponsiveSize rs,
    Color? accentColor,
  }) {
    final primaryColor = Theme.of(context).colorScheme.primary;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.onPrimary,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            blurRadius: 10,
            color: Colors.black.withValues(alpha: 0.08),
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: primaryColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, size: 20, color: primaryColor),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  fontSize: rs.titleFont,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          content,
        ],
      ),
    );
  }
}

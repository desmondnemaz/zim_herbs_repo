import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zim_herbs_repo/features/repository/herbs/data/models.dart';

import 'package:zim_herbs_repo/features/repository/herbs/bloc/herb_bloc.dart';
import 'package:zim_herbs_repo/features/repository/herbs/bloc/herb_event.dart';
import 'package:zim_herbs_repo/features/repository/herbs/bloc/herb_state.dart';
import 'package:zim_herbs_repo/features/repository/herbs/presentation/components/desktop_herb_list.dart';
import 'package:zim_herbs_repo/features/repository/herbs/presentation/components/mobile_herb_list.dart';
import 'package:zim_herbs_repo/core/theme/spacing.dart';
import 'package:zim_herbs_repo/core/utils/responsive.dart';
import 'package:zim_herbs_repo/core/utils/responsive_sizes.dart';
import 'package:zim_herbs_repo/features/admin/herb_management/presentation/add_edit_herb_page.dart';

class HerbsList extends StatefulWidget {
  const HerbsList({super.key});

  @override
  State<HerbsList> createState() => _HerbsListState();
}

class _HerbsListState extends State<HerbsList> {
  // We no longer need _herbsFuture or searchQuery here!
  // The BLoC will manage those for us.

  @override
  void initState() {
    super.initState();
    // No initState logic needed here if we use BlocProvider(create: ...)
  }

  void _handleDelete(BuildContext context, HerbModel herb) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Delete Herb'),
            content: Text('Are you sure you want to delete "${herb.nameEn}"?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text(
                  'Delete',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          ),
    );

    if (confirm == true && context.mounted) {
      context.read<HerbBloc>().add(DeleteHerb(herb.id));
    }
  }

  Future<void> _showAddEditDialog(
    BuildContext context, {
    HerbModel? herb,
  }) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AddEditHerbPage(herb: herb)),
    );

    if (result == true) {
      // If the page returned "true", it means something changed.
      // Tell the Bloc to reload.
      if (mounted && context.mounted) {
        context.read<HerbBloc>().add(RefreshHerbs());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final rs = ResponsiveSize(context);

    // We use the global HerbBloc
    return Builder(
      builder: (context) {
        // Trigger a load if it's not already loaded
        final currentBlocState = context.read<HerbBloc>().state;
        if (currentBlocState is HerbInitial) {
          context.read<HerbBloc>().add(LoadHerbs());
        }

        return BlocListener<HerbBloc, HerbState>(
          listener: (context, state) {
            if (state is HerbOperationSuccess) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(state.message)),
              );
            } else if (state is HerbError) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(state.message),
                  backgroundColor: Colors.red,
                ),
              );
            }
          },
          child: Builder(
            builder: (context) {
              return Scaffold(
                appBar: Responsive.isDesktop(context)
                    ? null
                    : AppBar(
                        toolbarHeight: 10,
                        elevation: 0,
                        backgroundColor: Theme.of(context).colorScheme.primary,
                      ),
                floatingActionButton: Builder(
                  builder: (context) => FloatingActionButton(
                    tooltip: 'Add Herb',
                    onPressed: () => _showAddEditDialog(context),
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(
                        color: Theme.of(context).colorScheme.secondary,
                        width: 4,
                      ),
                    ),
                    child: const Icon(Icons.add, color: Colors.white),
                  ),
                ),
                body: SafeArea(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Theme.of(context).scaffoldBackgroundColor,
                    ),
                    child: Column(
                      children: [
                        // Header
                        _buildHeader(context, rs),

                        // Counter
                        BlocBuilder<HerbBloc, HerbState>(
                          builder: (context, state) {
                            if (state is HerbLoaded) {
                              return Padding(
                                padding: const EdgeInsets.only(
                                  top: 8,
                                  right: 20,
                                  bottom: 0,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      "Total: ${state.herbs.length}",
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary
                                            .withValues(alpha: 0.7),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }
                            return const SizedBox.shrink();
                          },
                        ),

                        // Search Bar
                        _buildSearchBar(context),

                        // HERBS LIST
                        Expanded(
                          child: BlocBuilder<HerbBloc, HerbState>(
                            builder: (context, state) {
                              if (state is HerbLoading || state is HerbInitial) {
                                return const Center(
                                  child: CircularProgressIndicator(),
                                );
                              }

                              if (state is HerbError) {
                                return Center(child: Text(state.message));
                              }

                              if (state is HerbLoaded) {
                                if (state.herbs.isEmpty) {
                                  return _buildEmptyView(state.searchQuery);
                                }

                                return Responsive.isMobile(context)
                                    ? MobileHerbList(
                                        filteredHerbs: state.herbs,
                                        rs: rs,
                                        onEdit: (herb) => _showAddEditDialog(
                                          context,
                                          herb: herb,
                                        ),
                                        onDelete: (herb) =>
                                            _handleDelete(context, herb),
                                      )
                                    : DesktopHerbList(
                                        filteredHerbs: state.herbs,
                                        rs: rs,
                                        onEdit: (herb) => _showAddEditDialog(
                                          context,
                                          herb: herb,
                                        ),
                                        onDelete: (herb) =>
                                            _handleDelete(context, herb),
                                      );
                              }

                              return const SizedBox.shrink();
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildHeader(BuildContext context, ResponsiveSize rs) {
    return Container(
      padding: EdgeInsets.all(defaultPadding),
      decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary),
      child: Row(
        children: [
          InkWell(
            onTap: () => Navigator.pop(context),
            child: Icon(
              Icons.arrow_back,
              color: Theme.of(context).colorScheme.secondary,
              size: rs.appBarIcon,
            ),
          ),
          SizedBox(width: defaultPadding),
          Text(
            "All Herbs",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.secondary,
              fontSize: rs.appBarTitleFont,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: TextField(
        onChanged: (value) {
          // STEP 3: Instead of setState, we just send a new Order (Event) to the Chef
          context.read<HerbBloc>().add(SearchHerbs(value));
        },
        decoration: InputDecoration(
          hintText: "Search herbs...",
          filled: true,
          fillColor: Theme.of(context).colorScheme.onPrimary,
          prefixIcon: Icon(
            Icons.search,
            color: Theme.of(context).colorScheme.primary,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyView(String query) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.search_off, size: 64, color: Colors.grey),
          const SizedBox(height: 16),
          Text(
            query.isEmpty
                ? 'No herbs available'
                : 'No herbs found for "$query"',
            style: const TextStyle(fontSize: 18, color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
